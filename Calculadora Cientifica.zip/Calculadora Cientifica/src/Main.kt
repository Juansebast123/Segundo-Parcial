fun main() {
    val calculadoraCtf = CalculadoraCientifica()

    while (true) {
        println("1. Resolver expresion.")
        println("2. Convertir de Radianes a Grados.")
        println("3. Convertir de Grados a Radianes.")
        println("4. Salir.")
        print("Seleccione una opción: ")
        val opcion = readLine()?.toIntOrNull()

        if (opcion != null && opcion in 1..4){
            when (opcion) {
                1 -> {
                    print("Ingrese la expresion: ")
                    val expresion = readLine()?.replace(" ", "") ?: ""

                    try {
                        val resultado = calculadoraCtf.resolverExpresion(expresion)
                        println("Resultado: " + resultado)
                    } catch (e: Exception) {
                        println("ERROR Sintactico")
                    }
                }

                2 -> {
                    print("Ingrese el valor en radianes: ")
                    val radianes = readLine()?.toDoubleOrNull()
                    if (radianes != null) {
                        println("Resultado en grados: " + calculadoraCtf.radianesAgrados(radianes))
                    } else {
                        println("ERROR Sintactico")
                    }
                }

                3 -> {
                    println("Ingrese el valor en grados:")
                    val grados = readLine()?.toDoubleOrNull()
                    if (grados != null) {
                        println("Resultado en radianes: " + calculadoraCtf.gradosAradianes(grados))
                    } else {
                        println("ERROR Sintactico")
                    }
                }

                4 -> {
                    println("Saliendo del programa.")
                    break
                }
            }
        }
    }
}

