import kotlin.math.*

open class Calculadora {

    fun sumar(a: Double, b: Double): Double = a + b

    fun restar(a: Double, b: Double): Double = a - b

    fun multiplicar(a: Double, b: Double): Double = a * b

    fun dividir(a: Double, b: Double): Double {
        if (b == 0.0)
            println("ERROR Matematico")
        return a / b
    }

    fun potencia (x: Int, a: Int): Int = x.toDouble().pow(a).toInt()

    open fun potencia(x: Double, a: Double): Double = x.pow(a)
}