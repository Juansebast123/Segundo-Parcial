import kotlin.math.*

class CalculadoraCientifica : Calculadora() {

    fun seno(x: Double): Double {
        return sin(x)
    }

    fun coseno (x: Double): Double{
        return cos(x)
    }

    fun tangente(x: Double): Double{
        return tan(x)
    }

    override fun potencia(x: Double, a: Double): Double{
        return if (x == 1.0 / 3.0) {
            x.pow(1.0/3.0)
        } else {
            super.potencia(x, a)
        }
    }

    fun raizCuadrada(x: Double): Double{
        if (x < 0)
            println("ERROR Matematico")
        return sqrt(x)
    }

    fun raizCubica(x: Double): Double{
        if ( x < 0)
            println("ERROR Matematico")
        return x.pow(1.0/3.0)
    }

    fun logaritmo10(x: Double): Double{
        if (x <= 0)
            println("ERROR Matematico")
        return log10(x)
    }

    fun logaritmoNatural(x: Double): Double{
        if (x <= 0)
            println("ERROR Matematico")
        return ln(x)
    }

    fun exponencial(x: Double): Double{
        return exp(x)
    }

    fun gradosAradianes(x: Double): Double {
        return Math.toRadians(x)
    }

    fun radianesAgrados(x: Double): Double{
        return Math.toDegrees(x)
    }

    fun tokenize(expresion: String): List<String> {
        val buscaOp = Regex("""(\d+(\.\d+)?|[+*/()-]|sin\(|cos\(|tan\(|sqrt\(|sqrt3\(|log\(|ln\(|exp\(|pow\()""")
        return buscaOp.findAll(expresion).map { it.value }.toList()
    }

    fun resolverExpresion(expresion: String): Double{
        val tokens = tokenize(expresion)
        val pila = mutableListOf<Double>()
        val operadores = mutableListOf<String>()
        val precedencia = mapOf("+" to 1, "-" to 1, "*" to 2, "/" to 2, "sin(" to 3, "cos(" to 3, "tan(" to 3, "sqrt(" to 3, "sqrt3(" to 3, "log(" to 3, "ln(" to 3, "exp(" to 3,"pow(" to 3)

        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null -> pila.add(token.toDouble())

                token in precedencia.keys -> {
                    while (operadores.isNotEmpty() && operadores.last() != "(" && precedencia[operadores.last()]!! >= precedencia[token]!!) {
                        aplicarOperador(operadores.removeAt(operadores.size - 1), pila)
                    }
                    operadores.add(token)
                }

                token == "(" -> operadores.add(token)

                token == ")" -> {
                    while (operadores.isNotEmpty() && operadores.last() != "(") {
                        aplicarOperador(operadores.removeAt(operadores.size - 1), pila)
                    }
                    if (operadores.isNotEmpty() && operadores.last() == "(") operadores.removeAt(operadores.size - 1)
                }
            }
        }

        while (operadores.isNotEmpty()) {
            aplicarOperador(operadores.removeAt(operadores.size - 1), pila)
        }
        return pila.last()
    }

    fun aplicarOperador(operador: String, pila: MutableList<Double>) {
        val calculadora = Calculadora()
        val calculadoraCientifica = CalculadoraCientifica()

        when (operador) {
            "+" -> pila.add(calculadora.sumar(pila.removeAt(pila.size - 2), pila.removeAt(pila.size - 1)))
            "-" -> pila.add(calculadora.restar(pila.removeAt(pila.size - 2), pila.removeAt(pila.size - 1)))
            "*" -> pila.add(calculadora.multiplicar(pila.removeAt(pila.size - 2), pila.removeAt(pila.size - 1)))
            "/" -> pila.add(calculadora.dividir(pila.removeAt(pila.size - 2), pila.removeAt(pila.size - 1)))
            "sin(" -> pila.add(calculadoraCientifica.seno(pila.removeAt(pila.size - 1)))
            "cos(" -> pila.add(calculadoraCientifica.coseno(pila.removeAt(pila.size - 1)))
            "tan(" -> pila.add(calculadoraCientifica.tangente(pila.removeAt(pila.size - 1)))
            "sqrt(" -> pila.add(calculadoraCientifica.raizCuadrada(pila.removeAt(pila.size - 1)))
            "sqrt3(" -> pila.add(calculadoraCientifica.raizCubica(pila.removeAt(pila.size - 1)))
            "log(" -> pila.add(calculadoraCientifica.logaritmo10(pila.removeAt(pila.size - 1)))
            "ln(" -> pila.add(calculadoraCientifica.logaritmoNatural(pila.removeAt(pila.size - 1)))
            "exp(" -> pila.add(calculadoraCientifica.exponencial(pila.removeAt(pila.size - 1)))
            "pow(" -> {
                val exponente = pila.removeAt(pila.size - 1)
                val base = pila.removeAt(pila.size - 1)
                pila.add(calculadoraCientifica.potencia(base, exponente))
            }
        }
    }
}
